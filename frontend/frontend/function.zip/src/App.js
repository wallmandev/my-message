import React, { useState, useEffect } from 'react';
import axios from 'axios';

const apiBaseUrl = 'https://rto8u369c7.execute-api.eu-north-1.amazonaws.com/dev';

function App() {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState({ username: '', text: '' });

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      const response = await axios.get(`${apiBaseUrl}/messages`);
      setMessages(response.data);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const postMessage = async () => {
    try {
      await axios.post(`${apiBaseUrl}/messages`, newMessage);
      fetchMessages();
      setNewMessage({ username: '', text: '' });
    } catch (error) {
      console.error('Error posting message:', error);
    }
  };

  const updateMessage = async (id) => {
    const updatedText = prompt('Ange ny text för meddelandet:');
    if (updatedText) {
      try {
        await axios.put(`${apiBaseUrl}/messages/${id}`, { text: updatedText });
        fetchMessages();
      } catch (error) {
        console.error('Error updating message:', error);
      }
    }
  };

  return (
    <div>
      <h1>Message Board</h1>
      <div>
        <input
          type="text"
          placeholder="Username"
          value={newMessage.username}
          onChange={(e) => setNewMessage({ ...newMessage, username: e.target.value })}
        />
        <textarea
          placeholder="Message"
          value={newMessage.text}
          onChange={(e) => setNewMessage({ ...newMessage, text: e.target.value })}
        />
        <button onClick={postMessage}>Post Message</button>
      </div>
      <ul>
        {messages.map((message) => (
          <li key={message.id}>
            <p>{message.username}: {message.text}</p>
            <button onClick={() => updateMessage(message.id)}>Edit</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
