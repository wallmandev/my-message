const { DynamoDBClient, PutItemCommand, ScanCommand, UpdateItemCommand } = require('@aws-sdk/client-dynamodb');
const { v4: uuidv4 } = require('uuid');

// Skapa en ny DynamoDB-klient
const dynamoDbClient = new DynamoDBClient({ region: 'us-east-1' });

const TableName = process.env.DYNAMODB_TABLE;

// Grundläggande CORS-headers som ska användas i alla svar
const headers = {
  "Access-Control-Allow-Origin": "http://localhost:3000", // Ändra till din specifika domän om nödvändigt
  "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET" // Lägg till alla metoder du vill tillåta
};

// Hantera alla HTTP-metoder och CORS-förfrågningar
exports.handler = async (event) => {
  // Hantera preflight-förfrågningar (OPTIONS)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: headers,
      body: JSON.stringify({ message: "CORS preflight check successful" }),
    };
  }

  // Kalla på rätt funktion beroende på HTTP-metoden och endpoint
  switch (event.httpMethod) {
    case 'GET':
      return await module.exports.getMessages(event);
    case 'POST':
      return await module.exports.createMessage(event);
    case 'PUT':
      return await module.exports.updateMessage(event);
    default:
      return {
        statusCode: 405,
        headers: headers,
        body: JSON.stringify({ message: `Method ${event.httpMethod} not allowed` }),
      };
  }
};

// Skapa ett nytt meddelande
module.exports.createMessage = async (event) => {
  const { username, text } = JSON.parse(event.body);
  const id = uuidv4();
  const createdAt = Date.now();

  const params = {
    TableName,
    Item: {
      id: { S: id },
      username: { S: username },
      text: { S: text },
      createdAt: { N: createdAt.toString() },
    },
  };

  try {
    // Använd PutItemCommand för att sätta in ett objekt i DynamoDB
    await dynamoDbClient.send(new PutItemCommand(params));
    return {
      statusCode: 201,
      headers: headers,
      body: JSON.stringify(params.Item),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: headers,
      body: JSON.stringify({ error: 'Could not create message' }),
    };
  }
};

// Hämta alla meddelanden
module.exports.getMessages = async (event) => {
  const params = { TableName };

  try {
    // Använd ScanCommand för att hämta alla objekt i tabellen
    const result = await dynamoDbClient.send(new ScanCommand(params));
    return {
      statusCode: 200,
      headers: headers,
      body: JSON.stringify(result.Items),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: headers,
      body: JSON.stringify({ error: 'Could not retrieve messages' }),
    };
  }
};

// Uppdatera ett meddelande
module.exports.updateMessage = async (event) => {
  const { id } = event.pathParameters;
  const { text } = JSON.parse(event.body);
  const params = {
    TableName,
    Key: { id: { S: id } },
    UpdateExpression: 'set text = :text',
    ExpressionAttributeValues: {
      ':text': { S: text },
    },
    ReturnValues: 'ALL_NEW',
  };

  try {
    // Använd UpdateItemCommand för att uppdatera objekt i DynamoDB
    const result = await dynamoDbClient.send(new UpdateItemCommand(params));
    if (!result.Attributes) {
      return {
        statusCode: 404,
        headers: headers,
        body: JSON.stringify({ error: 'Message not found' }),
      };
    }
    return {
      statusCode: 200,
      headers: headers,
      body: JSON.stringify(result.Attributes),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: headers,
      body: JSON.stringify({ error: 'Could not update message' }),
    };
  }
};

// const { DynamoDBClient, PutItemCommand, ScanCommand, UpdateItemCommand } = require('@aws-sdk/client-dynamodb');
// const { v4: uuidv4 } = require('uuid');

// // Skapa en ny DynamoDB-klient
// const dynamoDbClient = new DynamoDBClient({ region: 'us-east-1' });

// const TableName = process.env.DYNAMODB_TABLE;

// // Skapa ett nytt meddelande
// module.exports.createMessage = async (event) => {
//   const { username, text } = JSON.parse(event.body);
//   const id = uuidv4();
//   const createdAt = Date.now();

//   const params = {
//     TableName,
//     Item: {
//       id: { S: id },
//       username: { S: username },
//       text: { S: text },
//       createdAt: { N: createdAt.toString() },
//     },
//   };

//   try {
//     // Använd PutItemCommand för att sätta in ett objekt i DynamoDB
//     await dynamoDbClient.send(new PutItemCommand(params));
//     return {
//       statusCode: 201,
//       headers: {
//         "Access-Control-Allow-Origin": "http://localhost:3000",
//         "Access-Control-Allow-Headers": "Content-Type",
//         "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
//       },
//       body: JSON.stringify(params.Item),
//     };
//   } catch (error) {
//     return {
//       statusCode: 500,
//       headers: {
//         "Access-Control-Allow-Origin": "http://localhost:3000",
//         "Access-Control-Allow-Headers": "Content-Type",
//         "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
//       },
//       body: JSON.stringify({ error: 'Could not create message' }),
//     };
//   }
// };

// // Hämta alla meddelanden
// module.exports.getMessages = async () => {
//   const params = {
//     TableName,
//   };

//   try {
//     // Använd ScanCommand för att hämta alla objekt i tabellen
//     const result = await dynamoDbClient.send(new ScanCommand(params));
//     return {
//       statusCode: 200,
//       headers: {
//         "Access-Control-Allow-Origin": "http://localhost:3000", // Ändra till din specifika domän om nödvändigt, t.ex. "http://localhost:3000"
//         "Access-Control-Allow-Headers": "Content-Type",
//         "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
//       },
//       body: JSON.stringify(result.Items),
//     };
//   } catch (error) {
//     return {
//       statusCode: 500,
//       headers: {
//         "Access-Control-Allow-Origin": "http://localhost:3000",
//         "Access-Control-Allow-Headers": "Content-Type",
//         "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
//       },
//       body: JSON.stringify({ error: 'Could not retrieve messages' }),
//     };
//   }
// };

// // Uppdatera ett meddelande
// module.exports.updateMessage = async (event) => {
//   const { id } = event.pathParameters;
//   const { text } = JSON.parse(event.body);
//   const params = {
//     TableName,
//     Key: { id: { S: id } },
//     UpdateExpression: 'set text = :text',
//     ExpressionAttributeValues: {
//       ':text': { S: text },
//     },
//     ReturnValues: 'ALL_NEW',
//   };

//   try {
//     // Använd UpdateItemCommand för att uppdatera objekt i DynamoDB
//     const result = await dynamoDbClient.send(new UpdateItemCommand(params));
//     if (!result.Attributes) {
//       return {
//         statusCode: 404,
//         headers: {
//           "Access-Control-Allow-Origin": "http://localhost:3000",
//           "Access-Control-Allow-Headers": "Content-Type",
//           "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
//         },
//         body: JSON.stringify({ error: 'Message not found' }),
//       };
//     }
//     return {
//       statusCode: 200,
//       headers: {
//         "Access-Control-Allow-Origin": "http://localhost:3000",
//         "Access-Control-Allow-Headers": "Content-Type",
//         "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
//       },
//       body: JSON.stringify(result.Attributes),
//     };
//   } catch (error) {
//     return {
//       statusCode: 500,
//       headers: {
//         "Access-Control-Allow-Origin": "http://localhost:3000",
//         "Access-Control-Allow-Headers": "Content-Type",
//         "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
//       },
//       body: JSON.stringify({ error: 'Could not update message' }),
//     };
//   }
// };

// const AWS = require('aws-sdk');
// const dynamoDb = new AWS.DynamoDB.DocumentClient();
// const { v4: uuidv4 } = require('uuid');

// const TableName = process.env.DYNAMODB_TABLE;

// // Skapa ett nytt meddelande
// module.exports.createMessage = async (event) => {
//   const { username, text } = JSON.parse(event.body);
//   const id = uuidv4();
//   const createdAt = Date.now();

//   const params = {
//     TableName,
//     Item: {
//       id,
//       username,
//       text,
//       createdAt,
//     },
//   };

//   try {
//     await dynamoDb.put(params).promise();
//     return {
//       statusCode: 201,
//       body: JSON.stringify(params.Item),
//     };
//   } catch (error) {
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: 'Could not create message' }),
//     };
//   }
// };

// // Hämta alla meddelanden
// module.exports.getMessages = async () => {
//   const params = {
//     TableName,
//   };

//   try {
//     const result = await dynamoDb.scan(params).promise();
//     return {
//       statusCode: 200,
//       body: JSON.stringify(result.Items),
//     };
//   } catch (error) {
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: 'Could not retrieve messages' }),
//     };
//   }
// };

// // Uppdatera ett meddelande
// module.exports.updateMessage = async (event) => {
//   const { id } = event.pathParameters;
//   const { text } = JSON.parse(event.body);
//   const params = {
//     TableName,
//     Key: { id },
//     UpdateExpression: 'set text = :text',
//     ExpressionAttributeValues: {
//       ':text': text,
//     },
//     ReturnValues: 'ALL_NEW',
//   };

//   try {
//     const result = await dynamoDb.update(params).promise();
//     if (!result.Attributes) {
//       return { statusCode: 404, body: JSON.stringify({ error: 'Message not found' }) };
//     }
//     return { statusCode: 200, body: JSON.stringify(result.Attributes) };
//   } catch (error) {
//     return { statusCode: 500, body: JSON.stringify({ error: 'Could not update message' }) };
//   }
// };